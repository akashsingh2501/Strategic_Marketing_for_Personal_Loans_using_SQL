# Strategic_Marketing_for_Personal_Loans_using_Python_and_SQL.

## Project Description
Thera Bank is upgrading its marketing strategies through data-driven customer segmentation. Analyzing demographics, finances, and behavior, the project aims to pinpoint groups more likely to switch from liability to personal loans. Using digital channels and personalized messages, the goal is to boost campaign success, trim costs, and strengthen customer retention, leading to increased revenue growth.
